﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverPush
{
    public interface IObserver
    {
        void Update(SubjectData subjectData);
    }
}
